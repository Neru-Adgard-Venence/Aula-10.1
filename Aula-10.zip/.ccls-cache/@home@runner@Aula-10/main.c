#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define TAMANHO_VETOR 6
#define MAXIMO_VALOR 50

int existeNoVetor(int vetor[], int tamanho, int numero) {
    for (int i = 0; i < tamanho; i++) {
        if (vetor[i] == numero) {
            return 1; 
            
        }
    }
    return 0;
    
}

void ordenarVetor(int vetor[], int tamanho) {
    int temp;
    for (int i = 0; i < tamanho - 1; i++) {
        for (int j = 0; j < tamanho - i - 1; j++) {
            if (vetor[j] > vetor[j + 1]) {
                temp = vetor[j];
                vetor[j] = vetor[j + 1];
                vetor[j + 1] = temp;
            }
        }
    }
}

int main() {
    int numeros[TAMANHO_VETOR];
    int numeroSorteado, indice = 0;

    srand(time(NULL));

    while (indice < TAMANHO_VETOR) {
        numeroSorteado = rand() % MAXIMO_VALOR + 1;
        if (!existeNoVetor(numeros, indice, numeroSorteado)) {
            numeros[indice] = numeroSorteado;
            indice++;
        }
    }
    
    ordenarVetor(numeros, TAMANHO_VETOR);

    printf("Números sorteados e ordenados: ");
    for (int i = 0; i < TAMANHO_VETOR; i++) {
        printf("%d ", numeros[i]);
    }
    printf("\n");

    return 0;
}